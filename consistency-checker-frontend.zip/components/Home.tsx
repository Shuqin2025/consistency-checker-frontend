// 📄 Home.tsx
// 内容从 canvas index.tsx 拆分而来（见 Chat 历史）

import React, { useState } from "react";
import axios from "axios";
import InteractiveReviewPanel from "./InteractiveReviewPanel";
import ErrorSummaryTable from "./ErrorSummaryTable";
import ExportModule from "./ExportModule";

export default function Home() {
  const [file, setFile] = useState<File | null>(null);
  const [paragraphs, setParagraphs] = useState<any[]>([]);
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(false);

  const handleUpload = async () => {
    if (!file) return;
    setLoading(true);
    const formData = new FormData();
    formData.append("file", file);
    try {
      const res = await axios.post("http://localhost:5000/upload", formData);
      setParagraphs(res.data.paragraphs);
      const formatted = res.data.paragraphs.map((p: any) => ({
        id: p.id,
        original: p.text,
        review: "",
        modified: undefined,
      }));
      setResults(formatted);
    } catch (err) {
      alert("上传失败，请检查后端服务");
    }
    setLoading(false);
  };

  const handleCheck = async () => {
    if (results.length === 0) return;
    setChecking(true);
    try {
      const res = await axios.post("http://localhost:5000/check", {
        paragraphs: results.map((r) => ({ id: r.id, text: r.original })),
      });
      const updated = results.map((r, i) => ({ ...r, review: res.data.result[i].review }));
      setResults(updated);
    } catch (err) {
      alert("审查失败，请检查后端接口");
    }
    setChecking(false);
  };

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">📑 文稿一致性智能审查平台</h1>

      <input
        type="file"
        accept=".docx"
        onChange={(e) => setFile(e.target.files?.[0] || null)}
        className="mb-4"
      />
      <button
        onClick={handleUpload}
        className="bg-blue-600 text-white px-4 py-2 rounded mr-4"
        disabled={loading}
      >
        {loading ? "上传中..." : "上传并解析"}
      </button>
      <button
        onClick={handleCheck}
        className="bg-green-600 text-white px-4 py-2 rounded"
        disabled={checking || results.length === 0}
      >
        {checking ? "审查中..." : "执行一致性审查"}
      </button>

      {results.some((r) => r.review) && (
        <>
          <InteractiveReviewPanel results={results} setResults={setResults} />
          <ErrorSummaryTable results={results} />
          <ExportModule results={results} />
        </>
      )}
    </div>
  );
}
