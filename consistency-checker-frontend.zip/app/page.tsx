'use client';
import Home from "../components/Home";
export default function Page() {
  return <Home />;
}
